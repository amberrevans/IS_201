#Amber Evans
#IS210-01

#Homework_1 directory
#Program 2-10

def averageTestscore ():
    test1 = int (input("Enter the first test score: "))
    test2 = int (input("Enter the second test score: "))
    test3 = int(input("Enter the third test score: "))

    average = (test1+test2+test3)/3

    print("The average score is: ",average)
    return
averageTestscore()
