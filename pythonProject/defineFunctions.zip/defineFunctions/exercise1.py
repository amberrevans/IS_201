#mailing address

def mailingAddress ():
    print('Amber Evans')
    print('209 Sagebrook Dr.')
    print('Madison, AL 35757')
    return
mailingAddress()
