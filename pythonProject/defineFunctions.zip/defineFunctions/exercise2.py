#exercise2 Hello

def Hello ():
    name = (input('Enter your name: '))
    print ('Hello',name)
    return
Hello()
