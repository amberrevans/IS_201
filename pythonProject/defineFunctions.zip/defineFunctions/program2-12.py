#Amber Evans
#Homework_1 directory
#program 2-12

#This program allows the user to declare and initialize a variable by assigning
#it a value.

def age ():
    age = int (input('What is your age? '))
    print('You entered:',age)
    return
age()
