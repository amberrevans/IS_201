#Amber Evans
#Homework_1 directory
#Program 2-14

def raisingOcean ():
    yearly_rise = 1.5

    fiveYears = yearly_rise*5
    print('The ocean levels will rise',fiveYears,'millimeters in five years.')

    sevenYears = yearly_rise*7
    print ('The ocean levels will rise', sevenYears,'millimeters in seven years.')

    tenYears = yearly_rise*10
    print ('The ocean levels will rise',tenYears,'millimeters in ten years.')

    return
raisingOcean()
