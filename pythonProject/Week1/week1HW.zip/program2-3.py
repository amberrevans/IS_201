#Capture keyboard input and storage in variable age
age = input('What is your age?')

#Display both the string and the value of the varialbe age using one statement
#by default python auto adds a space when printing items seperated
#by a comma. In this case between the colon and the value of age.

print ('Here is the age that you entered: ', age)
