#Comments in Python start with a pound sign (#) and go to the end to the line
print("Amber Evans")
print ("209 Sagebrook Drive")
print ("Madison, AL 35757")

input()
