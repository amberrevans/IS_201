#The Python input function reads input from the keyboard
#By default the input is of the String data type
#The input is stored in the variable age
age = input("What is your age?")

#Display the string on the line by itself
print ("Here is the value that you entered: ")

#Display the value stored in the variable age
print (age)