#Comments in Python start with a pound sign (#) and go to the end to the line
print("Kate Austen")
print ("123 Full Circle Drive")
print ("Ashville, NC 28899")

input()