#Area of a room

length=float(input("Enter the length of the room in feet: "))
print('You entered:', length, 'as the length.')
width=float(input("Enter the width of the room in feet: "))
print('You entered:', width, 'as the width.')
area = length*width
print('The area of the room is', area, 'square feet.')

