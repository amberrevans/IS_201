name=(input('Please enter your name: '))
print("Hello", name)
