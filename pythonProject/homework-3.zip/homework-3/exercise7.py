#sum of positive integers

positiveNumber = int(input('Enter a positive number: '))
sumofNumbers= (positiveNumber * (positiveNumber + 1) // 2)
print (sumofNumbers)