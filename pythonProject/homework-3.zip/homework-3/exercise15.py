#feet, inches, yards, and miles

feet = int(input('Enter the distance in feet: '))

inches = feet *12
print('The distance in inches is',inches)

yards = feet/3
print ('The distance in yards is', yards)

miles= feet/5280
print ('the distance in miles is',miles)
