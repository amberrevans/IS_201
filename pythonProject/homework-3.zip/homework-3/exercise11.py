#convert mpg to L/100km

mpg = int(input('Please enter the Miles per Gallon you wish to convert: '))
print ('You entered', mpg)

#formula for conversion
km = mpg*235.215

print ('The conversion of', mpg,'miles per gallon to L/100km is', km,'L/100km')
