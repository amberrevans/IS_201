#Amber Evans
#IS210-01

#Homework_1 directory
#Program 2-14

#This program illustrates use of constants in Python

#Create a constant for the year rise
#The all caps name is one indication this is a constant
YEARLY_RISE = 1.5

#Calculate and display the amount of rises in five years
fiveYears = YEARLY_RISE * 5
print ("The ocean levels will rise", fiveYears, "millimeters in five years.")

#Calculate and display the amount of rise in seven years
sevenYears = YEARLY_RISE * 7
print("The ocean levels will rise", sevenYears, "millimeters in seven years.")

#Calculate and display the amount of rise in ten years
tenYears = YEARLY_RISE * 10
print("The ocean levels will rise", tenYears,"millimeters in ten years.")
