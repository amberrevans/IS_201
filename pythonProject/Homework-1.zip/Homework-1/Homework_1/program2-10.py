#Amber Evans
#IS210-01

#Homework_1 directory
#Program 2-10

#Capture user input for each test score, convert to Integer and store
test1 = int(input("Enter the first test score: "))
test2 = int(input("Enter the second test score: "))
test3= int(input("Enter the third test score: "))

#Calculate and store result in variable average as a float
average= (test1+test2+test3)/3

#Display the string and the value of average
print ("The average score is", average)
