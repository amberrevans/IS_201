#Amber Evans
#IS210-01

#Homework_1 directory
#program 2-12

#This program allows the user to declare and initialize a variable by assigning
#it a value.

#Convert user input to integer and store in variable age
age = int(input("What is your age? "))

#Display string and value of age with automatic space between
print ("Here is the age that you entered: ", age)
