#simple calculator
num_1=float(input("Enter a positive number: "))
num_2=float(input ("Enter a second positive number: "))
num_3=float(input("Enter a third positive number: "))

#addition
sum=(num_1+num_2+num_3)

#division
last= float(sum/2)
print(float(last))