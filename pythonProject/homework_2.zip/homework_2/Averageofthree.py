#average of three numbers
number_1= int(input("Enter a positive number: "))
number_2 = int(input("Enter a second positive number: "))
number_3 = int(input("Enter a third positive number: "))

average = (number_1 + number_2+number_3)/3

print("The average of the three numbers is", format (average,",.2f"))
