#Amber Evans
#This program converts celsius to fahrenheit

Celsius=int(input("Enter the temperature in Celsius: "))

#calculates from Celsius to Fahrenheit
Fahrenheit=((9/5)*Celsius)+32

#print results
print("The temperature in Fahrenheit is:", Fahrenheit)
