#inches to centimeters
inches=float(input("Please enter the legnth of the keyboard in inches: "))

#convert inches to centimeters
answer=float(inches*2.54)
print(answer)