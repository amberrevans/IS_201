#uppercase or lowercase

char = input('Enter a character: ')

if (char.islower()):
    print (char, 'is lowercase.')

else:
    print (char, 'is uppercase.')
