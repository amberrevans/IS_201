#input week number and print weekday

weekDay = int(input('Enter the weekday day number (1-7): '))

if weekDay ==1:
    print ('\nSunday');
elif weekDay == 2:
    print ('\nMonday')
elif weekDay ==3:
    print ('\nTuesday')
elif weekDay == 4:
    print ('\nWednesday')
elif weekDay ==5:
    print ('\nThursday')
elif weekDay == 6:
    print ('\nFriday')
else:
    print ('\nSunday')
